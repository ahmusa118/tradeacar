const express=require('express')
const app=express()
const cors=require('cors')
const bodyParser=require('body-parser')
const PayStack = require('paystack-node')
app.use(cors())

const path = require('path');
const ejs = require('ejs');
const authenticateToken = require('./auth/Authtoken');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
const url = require('url');
const jwt=require('jsonwebtoken')
require("dotenv").config()
const mongoose=require('mongoose')
const multer=require('multer')
const Car = require('./models/Car');
const Signupmodel=require('./models/Signupmodel')
let dat=null
app.set('view engine', 'ejs');
const APIKEY = 'sk_test_f2c71386864743ac7450134fc0e65b7ae3fc588a';
const environment = 'test'; // Use 'live' for production environment
const secretKey = require('./config');
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Set the destination folder for uploaded files
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    // Set the filename for uploaded files
    cb(null, Date.now() + '-' + file.originalname);
  }
});

// Create the Multer upload instance


// Use Multer middleware for file uploads
const upload = multer({
  storage: storage,
  limits: { files: 5 } // Set the maximum number of files allowed to 5
});

// POST route for uploading images
app.post('/upload', upload.array('images', 5), (req, res) => {
  const {
    region,
    make,
    color,
    condition,
    transmission,
    mileage,
    vin,
    registered,
    description,
    price,
    negotiable,
    sellerPhoneNumber,
    email,
  } = req.body;

  const images = req.files.map((file) => file.path);
/*dat=email*/
  const car = new Car({
    region,
    make,
    color,
    condition,
    transmission,
    mileage,
    vin,
    registered,
    description,
    price,
    negotiable,
    sellerPhoneNumber,
    email,
    images,
  });

  car.save()
    .then(() => {
      res.status(200).send('Car data saved successfully');
    })
    .catch((error) => {
      res.status(500).send('Error saving car data');
      console.error('Error saving car data:', error);
    });
})

app.get("/", function(req, res) {
  res.sendFile(__dirname + "/index.html");
})

app.get('/chg', (req, res) => {
  const email = dat; // Replace with your email value

  // Render the paystack template and pass the email variable as data
  res.render('paystack', { email });
});

const paystack = new PayStack(APIKEY, environment);



app.post('/userdetails', (req,res)=>{
    const {
      email,
      phone,
      firstName,
      lastName,
      password,
      nextOfKin,
      nextOfKinPhone,
      address,
      state
    } = req.body;

    const newUser = new Signupmodel({
      email,
      phone,
      firstName,
      lastName,
      password,
      nextOfKin,
      nextOfKinPhone,
      address,
      state
    });
    newUser.save()
    .then(() => {
      res.status(200).send('user data saved successfully');
    })
    .catch((error) => {
      res.status(500).send('Error saving car data');
      console.error('Error saving car data:', error);
    });
    
})

app.post('/charge', (req, res) => {
  // Log the payment details received from Paystack
  console.log(req.body);

  // Process the payment details and perform any necessary actions

  // Send a response back to the client
  res.json({ success: true, message: 'Payment details received' });
})


app.post('/login', async (req, res) => {
const det = await Signupmodel.findOne({
  email: { $regex: new RegExp(req.body.email, 'i') },
  password: req.body.password
});
  if (!det) {
    res.status(404).json({ error: 'wrong username or password' });
  } else {
      
    const token = jwt.sign({ userId: det._id }, secretKey, { expiresIn: '1h' });
    res.json({ token });
      dat=det.email

  }
})

app.listen(3000,()=>{
    console.log('connected')
})

app.get('/dashboard', authenticateToken, async (req, res) => {
  const userId = req.userId;

  const house = await Signupmodel.findById(userId);

  if (!house) {
    res.status(404).json({ error: 'details not found' });
  } else {
    res.json(house);
  }
})

async function connectToMongoDB() {
  try {
    await mongoose.connect(process.env.URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('Connected to MongoDB');
    // Continue with your code after successful connection
  } catch (error) {
    console.error('Failed to connect to MongoDB:', error);
    // Handle error
  }
}
connectToMongoDB();
